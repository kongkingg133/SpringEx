/*
package com.human.pet.model;

public class Slime {
    private int Hp = 50;

    public int GetHp() {
        return this.Hp;
    }
}
*/
package com.human.pet.model;

public class Slime {
    private int Hp = 20;

    public int GetHp() {
        return Hp;
    }
}
